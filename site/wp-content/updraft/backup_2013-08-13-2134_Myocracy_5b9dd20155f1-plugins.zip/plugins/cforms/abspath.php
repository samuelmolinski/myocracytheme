<?php $abspath = 'C:\\wamp\\www\\myocracytheme\\site/'; ?>
