<?php
/**
 * Remove Dashboard Access Uninstall
 *
 * @since 1.0
 */

delete_option( 'rda-settings' );