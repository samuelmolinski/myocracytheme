<div id="header-container">
    <div class="row">		
        <div class="header-navigation">
            <div class="logo three columns">                        
                <a href="http://share2.cunjo.com" title="!Share" rel="home" target="_blank">
                    <h1 class="logo_text">!Share</h1>          
                </a>    
            </div><!-- END .logo -->        
        </div><!-- END .header-navigation -->
    </div><!-- END .row -->
    
</div>
<div class="well">
    <div class="row-fluid">
        <div class="span7 gallery">
            <h3>Introductory Video</h3>
            <ul>
            	<li>
                    <div class="thumb view" style="text-align: center;">
                        <iframe src="http://share2.cunjo.com/wp-content/themes/share/inc/video_lib.php" frameborder="0" style="width: 100%; height: 540px;text-align:center;"></iframe>
                    </div>
                </li>
            </ul>
        </div>
        <div class="span5">
            <h3>To do:</h3>
            <p><a href="<?php echo admin_url( 'admin.php?page=cunjoshare_Settings/SetSettings') ;?>" class="btn btn-primary btn-large btn-icon" style="padding: 10px 30px;"><i class="appz-cog" style="font-size:30px;vertical-align:middle;margin-right: 10px;"></i> 1. Setup General settings</a></p>
            <p><a href="<?php echo admin_url( 'admin.php?page=cunjoshare_Settings/ShowWidgets') ;?>" class="btn btn-primary btn-large btn-icon" style="padding: 10px 30px;"><i class="appz-archive" style="font-size:30px;vertical-align:middle;margin-right: 10px;"></i> 2. Activate & Customize Widgets</a></p>
            <p><a href="<?php echo admin_url( 'admin.php?page=cunjoshare_SocialAnalytics/LoadAnalytics') ;?>" class="btn btn-primary btn-large btn-icon" style="padding: 10px 30px;"><i class="appz-stats" style="font-size:30px;vertical-align:middle;margin-right: 10px;"></i> 3. View your Social Analytics</a></p>
            <p><a href="http://share2.cunjo.com/register/" target="_blank" class="btn btn-warning btn-large btn-icon" style="padding: 10px 30px;"><i class="appz-king" style="font-size:30px;vertical-align:middle;margin-right: 10px;"></i> 4. Upgrade for extra benefits</a></p>
            <p><a href="<?php echo admin_url( 'admin.php?page=cunjoshare_Settings/Credits') ;?>" class="btn btn-default btn-large btn-icon" style="padding: 10px 30px;"><i class="appz-info" style="font-size:30px;vertical-align:middle;margin-right: 10px;"></i> Credits and resources</a></p>
        </div>
    </div>
</div>