<h1>Saved settings</h1>
<?php
    echo "<pre>" . print_r($view_data, TRUE) . "</pre>";
?>

<p><small>I am from: <?php echo __FILE__; ?></small></p>