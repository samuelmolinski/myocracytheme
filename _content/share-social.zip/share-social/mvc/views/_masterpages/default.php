<header>
   <!-- header -->
</header> 
<?PHP echo $this->View($view); ?>
<footer>
     <!-- footer -->
</footer>