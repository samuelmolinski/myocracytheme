<div id="header-container">
	
    <div class="row">		
            
        <div class="header-navigation">
            
            <div class="logo three columns">
            
                        
            <a href="http://share2.cunjo.com" title="!Share" rel="home" target="_blank">
        
                            
                     <h1 class="logo_text">!Share</h1>
                     
                              
            </a>
    
                    
            </div><!-- END .logo -->
                            
        </div><!-- END .header-navigation -->
        
        <a href="http://share2.cunjo.com/register/" target="_blank" class="premium-upgrade" ><i class="appz-king"></i> Upgrade to Premium</a>
    </div><!-- END .row -->
    
</div>
<div class="row-fluid">
	<div class="widget widget-3">
		<div class="widget-head">
			<h3 class="heading">About !Share</h3>
		</div>
		<div class="widget-body">
        	<div class="row-fluid">
            	<div class="span6">
					<p>Current core version: <strong>2.0</strong></p>
                    <p>Lead developers: <strong>Biro Florin, Josh Foote</strong></p>
                    <p>!Share service home: <strong><a href="http://share.cunjo.com" target="_blank">share.cunjo.com</a></strong></p>
                    <p>Bugs and Support: <strong>support@cunjo.com</strong></p>
                </div>
                <div class="span6">
                	<p>Core plugin License: <strong><a href="http://www.gnu.org/licenses/gpl.html" target="_blank">GPLv2 or later</a></strong></p>
                	<p>Service developed and hosted by <strong><a href="http://cunjo.com" target="_blank">Cunjo.com</a></strong></p>
                    <p>Requests and Contributions: <strong>info@cunjo.com</strong></p>
                </div>
            </div>
		</div>
        <div class="widget-head">
			<h3 class="heading">Core Credits &amp; Contributions</h3>
		</div>
		<div class="widget-body">
        	<div class="row-fluid">
            	<div class="span6">
					<p>Shiny2 Icons Design: <strong><a href="http://sawb.deviantart.com/art/Social-Icons-Pack-123247215" target="_blank">Social Icons Pack + (by sawb)</a></strong></p>
                </div>
                <div class="span6">
                	
                </div>
            </div>
		</div>
        <!-- show credits for all widget bars -->
        
        <?php
        
            do_action('cunjo_display_credits', $view_data);
        
        ?>

    </div>
</div>