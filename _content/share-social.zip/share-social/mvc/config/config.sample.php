<?PHP
//sample config file
return array(
    'key' => 'value'
);
?>

