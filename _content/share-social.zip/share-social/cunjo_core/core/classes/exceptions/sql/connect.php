<?PHP
class expSQL_Connect extends expCore 
{
    
}
?>