<?PHP
class expModel404 extends exp404 
{
    
}
?>