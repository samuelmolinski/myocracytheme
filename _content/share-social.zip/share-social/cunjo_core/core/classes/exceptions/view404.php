<?PHP
class expView404 extends exp404 
{
    
}
?>