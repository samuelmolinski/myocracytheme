<?PHP
class expMethod extends expCore 
{
    
}
?>