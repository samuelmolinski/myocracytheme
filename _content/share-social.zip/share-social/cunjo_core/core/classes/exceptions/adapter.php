<?PHP
class expAdapter extends expCore 
{
    
}
?>