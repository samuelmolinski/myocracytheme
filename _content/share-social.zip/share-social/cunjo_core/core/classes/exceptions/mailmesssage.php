<?PHP
class expMailMessage extends expCore 
{
    
}
?>