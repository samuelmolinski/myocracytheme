<?PHP
class expMailPart extends expCore 
{
    
}
?>