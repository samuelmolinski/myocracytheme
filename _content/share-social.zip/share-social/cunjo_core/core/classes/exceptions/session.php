<?PHP
class expSession extends expCore 
{
    
}
?>