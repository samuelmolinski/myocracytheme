<?PHP
class exp404 extends expCore
{
    
}
?>