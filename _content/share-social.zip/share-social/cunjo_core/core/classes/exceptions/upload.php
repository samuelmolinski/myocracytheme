<?PHP
class expUpload extends expCore 
{
    
}
?>