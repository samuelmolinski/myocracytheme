<?PHP
class expHttp extends expCore 
{
    
}
?>