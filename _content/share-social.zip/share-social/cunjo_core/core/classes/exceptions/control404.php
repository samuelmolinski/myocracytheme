<?PHP
class expControl404 extends exp404 
{
    
}
?>