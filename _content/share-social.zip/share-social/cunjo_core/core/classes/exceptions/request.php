<?PHP
class expRequest extends expCore 
{
    
}
?>