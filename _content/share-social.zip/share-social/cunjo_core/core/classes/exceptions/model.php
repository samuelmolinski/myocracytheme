<?PHP
class expModel extends expCore 
{
    
}
?>