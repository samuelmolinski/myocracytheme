<?PHP
include '404.php'; 
?>