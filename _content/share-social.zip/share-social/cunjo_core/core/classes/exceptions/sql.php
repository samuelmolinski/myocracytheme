<?PHP
class expSQL extends expCore 
{
    
}
?>