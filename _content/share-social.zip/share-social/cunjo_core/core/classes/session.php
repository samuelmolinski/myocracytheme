<?php 
abstract class clsSession extends absSession {}
