<?PHP defined('_WP_FUEL_MVC') or die('No direct script access.');
include 'trace.php';
?>