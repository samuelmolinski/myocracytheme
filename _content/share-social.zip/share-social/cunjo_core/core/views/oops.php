<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>Something went wrong</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta http-equiv="X-UA-Compatible" content="IE=9" >
<meta name="robots"  content="noindex,follow" />
</head>
<body>

<div class="container middle">
    <div class="row">
         <br class="clear" />
         <div id="page-content"> 
 
            <div class="left-panel"> 

                <div class="content">

                    <h2 class="title">Oops! Something went wrong</h2> 
                    <div class="post-content"> 
                        <ul>
                            <li>Please bear with us while we iron out the kinks.</li>
                            <li>Notification has been sent to our technical team.</li>
                        </ul>
                    </div>
                    <br class="clearer" /> 
                </div> 

            </div>

            <br class="clearer" />

        </div> 
    </div>
</div>
</body>
</html>

