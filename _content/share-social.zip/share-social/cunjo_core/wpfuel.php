<?PHP
/* 
Plugin Name: !Share by Cunjo
Description: Cunjo !Share
Author: Josh Foote, Biro Florin
Version: 2.0.0
*/
if (!defined('ABSPATH'))
{
    exit; //block direct access
}

include_once 'load.php';
?>