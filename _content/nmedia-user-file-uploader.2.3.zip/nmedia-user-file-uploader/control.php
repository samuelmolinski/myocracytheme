<?php
$selected = 'selected = "selected"';
?>

<p>
	<label>Title<br>
    <input type="text" class="widefat" id="<?php echo $field_id_title?>" name="<?php echo $field_name_title?>" 
    value="<?php echo attribute_escape( $instance['nm_pt_title'] )?>" />
    </label>
</p>

