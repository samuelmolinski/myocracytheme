<?php

// deprecated
die();
